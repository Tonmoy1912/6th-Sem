// #include <bits/stdc++.h>
// using namespace std;
// int networkDelayTime(vector<vector<int> >& times, int n, int k) {
// 	int size=times.size();
// 	vector<pair<int,int> > adj[n+1];
// 	for(int i=0;i<size;i++){
// 		adj[times[i][0]].push_back(make_pair(times[i][1],times[i][2]));
// 	}
// 	priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > > test;
// 	test.push(make_pair(0,k));
// 	vector<int> distance(n+1,1e9);
// 	distance[0]=0;
// 	distance[k]=0;
// 	while(test.size()){
// 		pair<int,int> sample=test.top();
// 		test.pop();
// 		int dist=sample.first,node=sample.second;
// 		for(int i=0;i<adj[node].size();i++){
// 			pair<int,int> itr=adj[node][i];
// 			int curNode=itr.first;
// 			int curDist=itr.second;
// 			if(dist+curDist<distance[curNode]){
// 				distance[curNode]=dist+curDist;
// 				test.push(make_pair(dist+curDist,curNode));
// 			}
// 		}
// 	}
// 	int ans=-1;
// 	for(int i=0;i<n;i++){
// 		cout<<i<<" "<<distance[i]<<endl;
// 		// if(distance[i]==1e9){
// 		// 	return -1;
// 		// }
// 		// ans=max(ans,distance[i]);
// 	}
// 	return ans;
// }
// vector<int> test;
// int d=1e9;
// void path(vector<pair<int,int> > adj[],vector<int> t,int n,int k,int cost){
// 	if(n==k){
// 		if(cost<d){
// 			d=cost;
// 			test=t;
// 		}
// 		return ;
// 	}
// 	for(int i=0;i<adj[n].size();i++){
// 		t.push_back(adj[n][i].first);
// 		path(adj,t,adj[n][i].first,k,cost+adj[n][i].second);
// 	}

	
// }
// // main function
// int main()
// {
// 	vector<vector<int> > time;
// 	vector<int> arr;
// 	arr.push_back(0);arr.push_back(1);arr.push_back(4);	
// 	time.push_back(arr);
// 	arr.clear();
// 	arr.push_back(1);arr.push_back(4);arr.push_back(3);
// 	time.push_back(arr);
// 	arr.clear();
// 	arr.push_back(2);arr.push_back(3);arr.push_back(4);
// 	time.push_back(arr);
// 	arr.clear();
// 	arr.push_back(1);arr.push_back(2);arr.push_back(3);
// 	time.push_back(arr);
// 	arr.clear();
// 	arr.push_back(4);arr.push_back(3);arr.push_back(4);
// 	time.push_back(arr);
// 	arr.clear();
// 	arr.push_back(0);arr.push_back(2);arr.push_back(1);
// 	time.push_back(arr);
// 	arr.clear();
// 	arr.push_back(3);arr.push_back(1);arr.push_back(2);
// 	time.push_back(arr);
// 	arr.clear();
// 	arr.push_back(2);arr.push_back(4);arr.push_back(3);
// 	time.push_back(arr);
// 	arr.clear();
// 	int ans=networkDelayTime(time,5,0);
// 	cout<<ans<<endl;
// 	vector<pair<int,int> > adj[5];
// 	for(int i=0;i<5;i++){
// 		adj[time[i][0]].push_back(make_pair(time[i][1],time[i][2]));
// 	}
// 	 vector<int> t;
// 	path(adj,t,0,3,0);
// 	cout<<0<<" ";
// 	for(int i=0;i<test.size();i++){
// 		cout<<test[i]<<" ";
// 	}
// }


#include<bits/stdc++.h>
using namespace std;
vector<int> dijkstra(int n,vector<vector<pair<int,int>>> &adj)
{
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;
    vector<int> visited(n,0);
    vector<int> distance(n,INT_MAX);
    distance[0]=0;
    pq.push({0,0});
    while(!pq.empty())
    {
        int node=pq.top().second;
        int dist=pq.top().first;
        visited[node]=1;
        pq.pop();
        for(auto it:adj[node])
        {
            int adjnode=it.first;
            int wt=it.second;
            if(distance[adjnode]>wt+distance[node])
            {
                distance[adjnode]=wt+distance[node];
                pq.push({distance[adjnode],adjnode});
            }
        }
    }
    return distance;
}
void dijkstra_path(int src,int dest,int n,vector<vector<pair<int,int>>> &adj,vector<int> &parent)
{
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;
    vector<int> visited(n,0);
    vector<int> distance(n,INT_MAX);
    distance[src]=0;
    pq.push({0,src});
    while(!pq.empty())
    {
        int node=pq.top().second;
        int dist=pq.top().first;
        visited[node]=1;
        pq.pop();
        for(auto it:adj[node])
        {
            int adjnode=it.first;
            int wt=it.second;
            if(distance[adjnode]>wt+distance[node])
            {
                parent[adjnode]=node;
                distance[adjnode]=wt+distance[node];
                pq.push({distance[adjnode],adjnode});
            }
        }
    }
    cout<<"the parent vector is:";
    for(auto it:parent)
    cout<<it<<" ";
    cout<<endl;
    int node=dest;
    cout<<"The soln path is:";
    cout<<node<<"->";
    while(parent[node]!=-1)
    {
        if(node==src)
        cout<<parent[node];
        else
        cout<<parent[node]<<"->";
        node=parent[node];
    }
    cout<<endl;
}
int main(){
    int n,x,y;
    cout<<"Enter the number of elements in the graph:";
    cin>>n;
    int e;
    cout<<"Enter the number of edges in the graph:";
    cin>>e;
    vector<vector<pair<int,int>>> adj(n);
    int wt;
    for(int i=0;i<e;i++)
    {
        cout<<"Enter the edge:";
        cin>>x>>y;
        cout<<"Enter the edge weight=";
        cin>>wt;
        cout<<"Edge ["<<x<<","<<y<<"]="<<wt<<endl;
        adj[x].push_back({y,wt});
        adj[y].push_back({x,wt});
    }
    vector<int> parent(n,-1);
    vector<int> distance= dijkstra(n,adj);
    cout<<"the distance vector is :";
    for(auto it:distance)
    {
        cout<<it<<" ";
    }
    cout<<endl;
    int src,des;
    cout<<"/n"<<"enter the source nd the destination node respectively:";
    cin>>src>>des;
    dijkstra_path(src,des,n,adj,parent);
}