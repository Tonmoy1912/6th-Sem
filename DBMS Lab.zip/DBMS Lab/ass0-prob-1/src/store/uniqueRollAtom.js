import { atom } from "recoil";

export const rollAtom=atom({
    key:"rollAtom",
    default:1
});