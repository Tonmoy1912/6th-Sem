import { atom } from "recoil";

export const studentsAtom=atom({
    key:"studentsAtom",
    default:[]
});