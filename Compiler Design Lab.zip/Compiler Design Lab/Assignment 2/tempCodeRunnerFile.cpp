
	char alpha;		